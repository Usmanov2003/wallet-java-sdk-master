package com.gingernet.ethereum;

public class Deposit {

}
