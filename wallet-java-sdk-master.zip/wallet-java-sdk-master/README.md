# wallet-java-sdk

本代码包含Java版 BTC、USDT、 ETH 和 ETH 代币离线地址生成，离线签名，转账，确认转账；BTC ETH 多重签名。
